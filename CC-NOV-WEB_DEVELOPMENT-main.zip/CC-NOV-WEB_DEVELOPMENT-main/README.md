# CC-NOV-WEB_DEVELOPMENT
The task of facial emotion recognition involves detecting the sentiment portrayed by a person's face. Sentiment analysis refers to detecting the emotion or connotative notion an individual is conveying. The ways a human is capable of conveying sentiment is an extensive list.
