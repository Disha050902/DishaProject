# TextEditorApp
Java Advance Project 
