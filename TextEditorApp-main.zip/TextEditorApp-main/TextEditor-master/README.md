
# Text Editor

Text Editor is a free app that allows you to create, open, and edit text files on your computer.

![GitHub watchers](https://img.shields.io/github/watchers/viveknimbolkar/TextEditor?style=social)
## Demo

![](https://github.com/viveknimbolkar/TextEditor/blob/master/src/com/company/tedit.gif?raw=true)
